#' Hello data.
#'
#' A dataset containing two colums and 5 rows
#'
#'
#' @format A data frame with 5 rows and 2 variables:
#'
#' @param code : language code "en", "fr", "it", "es", "de" for "Engish", "Frensh", "Italian", "Espagnol", "German"
#'
#' @param    hello : language "hello" in the languages corresponding to the code
#' @author Khadija Sossey ksossey@yahoo.fr
#'
#'
#'
"language"
