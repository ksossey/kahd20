#' Hello World
#'
#' `hello` says _'Hello, world!'_ in the user specified language.
#' The user is asked to give her/his name so that the hello message gets personalize
#'
#'@param
#'   who a character vector of length 1 that specified the name of person
#'   to whom the message is addressed
#'@param
#'   lang a character vector of length 1 that specified the preferred language
#'@param
#'   LangData an optional data.frame with two columns. The first column gives the language codes and the second column gives the corresponding “hello” word
#'
#' @return a character vector with a personalized "hello" message
#'
#' @export

#' @importFrom stringr str_c
hello <- function(who, lang = "EN", LangData = Hello::language) {
  if (!exists("who", mode = "character") | length(who) > 1) stop("Please enter a valid namea; see ?hello")

  LangData <- data.frame(LangData)

  if (ncol(LangData) > 2) stop("Please enter a valid LangData; see ?hello")

  colnames(LangData) <- c("code", "hello")

  if ((mode(LangData$code) != "character") | (mode(LangData$hello) != "character")) stop("Please enter a valid LangData; see ?hello")

  llang <- tolower(lang)

  hello <- subset(LangData, LangData$code==llang)[[2]]

  cat(
    ifelse(
      length(hello) == 1,
      stringr::str_c(hello, ", ", who, "!", sep = ""),
      stringr::str_c("Sorry, ", who, ", ", "your language ", "('", lang, "') ", "is not available!", sep = "")
    )
  )
}


